name(pro2sql).
title('Lightweight translater of Prolog to SQL SELECT statements').
version('0.1.00').
author('Richard de Rozario','richard.derozario@gmail.com').
home('https://github.com/RdR1024/pro2sql').
download('https://github.com/RdR1024/prolog2gpt/raw/main/rel/pro2sql-0.1.00.zip').